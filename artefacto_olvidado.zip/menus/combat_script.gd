extends Node


var player_health
var rival_health
var artifact


func _on_ready() -> void:
	player_health = 100
	rival_health = 100
	#empiezan los botones apagados
	_disable_buttons()
	_player_turn()


func _disable_buttons() -> void:
	$"Camera2D/Buttons control/Consumir".disabled = true
	$"Camera2D/Buttons control/Utilizar".disabled = true
	pass


func _enable_buttons() -> void:
	$"Camera2D/Buttons control/Consumir".disabled = false
	$"Camera2D/Buttons control/Utilizar".disabled = false
	pass


func _player_lost() -> bool:
	if player_health <= 0:
		print("Perdiste, sos malisimo :(")
		return true
	return false

func _player_turn() -> void:
	if _player_lost():
		return
	#generamos un artefacto
	artifact = randi_range(-20, 10)
	_enable_buttons()

func _rival_lost() -> bool:
	if rival_health <= 0:
		print("Ganaste :D")
		return true
	return false

func _rival_turn() -> void:
	if _rival_lost():
		return
	_update_player_health(randi_range(-15, 0))
	_player_turn()


func _on_consumir_pressed() -> void:
	_disable_buttons()
	_update_player_health(artifact)
	if _player_lost():
		return
	_rival_turn()


func _on_utilizar_pressed() -> void:
	_disable_buttons()
	_update_rival_health(artifact)
	if _rival_lost():
		return
	_rival_turn()


func _on_surrender_pressed() -> void:	
	get_tree().change_scene_to_file("res://mainmenu.tscn")
	#salir


func _update_player_health(value) -> void:
	player_health += value
	$"Camera2D/Game Status/Player health".text = str(player_health)

func _update_rival_health(value) -> void:
	rival_health += value
	$"Camera2D/Game Status/Rival health".text = str(rival_health)
